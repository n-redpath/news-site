# CSE330
466259
458234

link to our amazing news site: http://ec2-18-219-184-237.us-east-2.compute.amazonaws.com/~sammkaiser/module3-group-module3-466259-458234/homepage.php

For the creative portion, we added two functions: search and a user profile page. For the search function, there is a search bar on our homepage that will bring up any stories matching the title typed in by the user. For the profile page, we added a button to each story that redirects to a page showing all of the stories written by that same author. 


To log in, a TA can either create an account, or use one of the accounts already created: 
Username: davidkaiser
Password: yeet
